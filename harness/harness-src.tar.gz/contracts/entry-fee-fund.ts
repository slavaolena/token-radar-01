// The entry fee's fund share (contracts/competition.ts EntryFee.fund_percent): how a fee splits between the make.fun
// fund and the bounty's pot, and the sentences every surface (server, cli, web) uses to tell people and agents about
// it, with the words for winnings still pending, which never pay a fee. The wording is tuned here alone.
//
// Split: fund_cents = floor(fee_cents * fund_percent / 100), pot_cents = fee_cents - fund_cents. A fee is whole cents;
// in base units a cent is 10^(decimals - 2) (USDC: 6 decimals, 10_000 base units a cent).
//
// A leaf: no imports at all, so the server, the cli and the web app all read it.

/** The fund's name as every sentence says it. */
export const FUND_NAME = 'the make.fun fund';

/** What the fund pays for, as every sentence says it (the user's words: more bounties, more content, expansion). */
export const FUND_PURPOSE = "which pays for more bounties, more content and make.fun's expansion";

/**
 * What winnings not cleared to pay yet are (server/entry-fees/eligible.ts EligibleWinnings.pendingCents), as every
 * surface says them: they never pay an entry fee until they are cleared. The insufficient_winnings refusal carries
 * their amount typed (EntryFeeProblem.winnings_pending_usd); these words only say what that amount is.
 */
export const PENDING_WINNINGS_WORDS = 'still pending (under review, held, or awaiting approval)';

/** Throws unless `p` is an integer 0..100 (EntryFee.fund_percent). */
function assertPercent(p: number): void {
  if (!Number.isInteger(p) || p < 0 || p > 100) throw new RangeError(`fund_percent ${p} is not an integer 0..100`);
}

/** The fee's fund percent: its fund_percent, 0 when absent (or no fee at all). */
export function fundPercentOf(entryFee: { fund_percent?: number } | null | undefined): number {
  return entryFee?.fund_percent ?? 0;
}

/**
 * A fee of `feeCents` (a whole number of cents, 0 or more) split at `fundPercent`: the fund's share rounded down to
 * the cent, the pot the rest. Throws on a fee that is not whole cents or a percent that is not an integer 0..100.
 */
export function entryFeeSplitCents(feeCents: number, fundPercent: number): { pot_cents: number; fund_cents: number } {
  if (!Number.isSafeInteger(feeCents) || feeCents < 0) throw new RangeError(`fee ${feeCents} is not a whole number of cents`);
  assertPercent(fundPercent);
  const fund_cents = Number((BigInt(feeCents) * BigInt(fundPercent)) / 100n);
  return { pot_cents: feeCents - fund_cents, fund_cents };
}

/**
 * A fee of `feeBaseUnits` (a token with `decimals` decimals) split at `fundPercent`, in whole cents as
 * entryFeeSplitCents splits it. Throws on decimals under 2 (or not an integer), a negative fee, a fee that is not
 * whole cents, or a percent that is not an integer 0..100.
 */
export function entryFeeSplitBaseUnits(feeBaseUnits: bigint, fundPercent: number, decimals: number): { pot: bigint; fund: bigint } {
  if (!Number.isInteger(decimals) || decimals < 2) throw new RangeError(`decimals ${decimals}: a cent needs 2 or more`);
  if (feeBaseUnits < 0n) throw new RangeError(`fee ${feeBaseUnits} base units is negative`);
  assertPercent(fundPercent);
  const cent = 10n ** BigInt(decimals - 2);
  if (feeBaseUnits % cent !== 0n) throw new RangeError(`fee ${feeBaseUnits} base units is not whole cents at ${decimals} decimals`);
  const fund = ((feeBaseUnits / cent) * BigInt(fundPercent)) / 100n * cent;
  return { pot: feeBaseUnits - fund, fund };
}

/** Where the fee goes, as one sentence: null at 0 (the whole fee joins the pot, as always). */
export function fundShareSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return `The whole entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; none of it joins this bounty's pot.`;
  return `${fundPercent}% of the entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; the other ${100 - fundPercent}% joins this bounty's pot.`;
}

/** What a no-place refund returns, as one sentence: null at 0 (the whole fee is refunded). */
export function fundRefundSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return 'None of it is refunded if nobody places.';
  return "The fund's share is never refunded: if nobody places, only the pot's share comes back.";
}
